/**
 * Write a description of interface CSALearnedSoFar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface CSALearnedSoFar  
{
}

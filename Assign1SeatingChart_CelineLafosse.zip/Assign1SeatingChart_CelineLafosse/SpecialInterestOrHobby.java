/**
 * Write a description of interface SpecialInterestOrHobby here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface SpecialInterestOrHobby  
{
    // method signatures - implement the signature below in your own class. Make sure to
    //                     match the parameter list and return type
    
    public void myHobby(String myHobbySentence);
}
